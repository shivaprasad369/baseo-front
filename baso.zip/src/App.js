// import Container from "./Components/Homepage/Container";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router";
// import ProductContaine from "./Components/Product/ProductContaine";
// import ProductSub from "./Components/ProductSub/ProductSub";
// import SubTwo from "./Components/SubTwoProducts.jsx/SubTwo";
// import Detail from "./Components/Details/Detail";
// import List from "./Components/Details/List";
// import Navbar from "./Components/Homepage/Navbar";
// import Categories from "./Components/Homepage/Categories";
// import Footer from "./Components/Homepage/Footer";
// import Register from "./Components/Authentivation/Register";
// import Login from "./Components/Authentivation/Login";
// import Checkout from "./Components/CheckOut/Checkout";
// import CheckoutSum from "./Components/CheckoutSum/CheckoutSum";
// import Success from "./Components/CheckoutSum/Success";
// import UserDashboard from "./Components/UserDashboard/UserDashboard";
// import Orderlist from "./Components/UserDashboard/Orderlist";
// import Wrapper from "./Components/UserDashboard/Wrapper";
// import Details from "./Components/UserDashboard/Details";
// import Profile from "./Components/UserDashboard/Profile";
// import Password from "./Components/UserDashboard/Password";
// import Home from "./Components/Homepage/Home";
import React, { Suspense } from "react";
import ErrorBoundary from "./Components/UI/Errorboundry.jsx";
import NotFoundPage from "./Components/UI/NotFoundPage .jsx";
const Home = React.lazy(()=>import('./Components/Homepage/Home'))
const Container = React.lazy(() => import('./Components/Homepage/Container'));
const ProductContaine = React.lazy(() => import("./Components/Product/ProductContaine"));
const ProductSub = React.lazy(() => import("./Components/ProductSub/ProductSub"));
const SubTwo = React.lazy(() => import("./Components/SubTwoProducts.jsx/SubTwo"));
const Detail = React.lazy(() => import("./Components/Details/Detail"));
const List = React.lazy(() => import("./Components/Details/List"));
const Navbar = React.lazy(() => import("./Components/Homepage/Navbar"));
const Categories = React.lazy(() => import("./Components/Homepage/Categories"));
const Footer = React.lazy(() => import("./Components/Homepage/Footer"));
const Register = React.lazy(() => import("./Components/Authentivation/Register"));
const Login = React.lazy(() => import("./Components/Authentivation/Login"));
const Checkout = React.lazy(() => import("./Components/CheckOut/Checkout"));
const CheckoutSum = React.lazy(() => import("./Components/CheckoutSum/CheckoutSum"));
const Success = React.lazy(() => import("./Components/CheckoutSum/Success"));
const UserDashboard = React.lazy(() => import("./Components/UserDashboard/UserDashboard"));
const Orderlist = React.lazy(() => import("./Components/UserDashboard/Orderlist"));
const Wrapper = React.lazy(() => import("./Components/UserDashboard/Wrapper"));
const Details = React.lazy(() => import("./Components/UserDashboard/Details"));
const Profile = React.lazy(() => import("./Components/UserDashboard/Profile"));
const Password = React.lazy(() => import("./Components/UserDashboard/Password"));
function App() {
  const apiUrl = process.env.REACT_APP_VARIABLE_NAME;
  // console.log(process.env)
console.log(apiUrl)
  const queryClient = new QueryClient();
  return (
    <QueryClientProvider client={queryClient}>
      <BrowserRouter>
      <ErrorBoundary fallback={<div>Something went wrong...</div>}>
      <Suspense fallback={<div className="w-[100vw] h-[100vh] flex items-center justify-center">
        <img src={require('./images/logo.png')} className="w-[10rem]" alt="Baseo" />
        </div>}>
        <List />
        <Home />
        <Navbar />
        <Categories />
        <Routes>
        <Route path="*" element={<NotFoundPage />} />
          <Route path="/" element={<Container />} />
          <Route path="/product/:id/:name" element={<ProductContaine />} />
          <Route path="/register" element={<Register />} />
          <Route path="/login" element={<Login />} />
          <Route path="/product/:id/:name/:subid/:subname"  element={<ProductSub />}/>
          <Route path="/product/:id/:name/:subid/:subname/:two/:twoname" element={<SubTwo />}/>
          <Route path="/products/details/:id/:name/:aid" element={<Detail />} />
          <Route path="/checkout" element={<Checkout />} />
          <Route path="/checkout-summary" element={<CheckoutSum />} />
          <Route path={`/order-success/:id`} element={<Success />} />
          <Route path={`/dashboard`} element={<UserDashboard />} />
          <Route path="user" element={<Wrapper />}>
            <Route path="list" element={<Orderlist />} />
            <Route path="details/:id" element={<Details />} />
            <Route path="profile/:id" element={<Profile />} />
            <Route path="change-password" element={<Password />} />

          </Route>
        </Routes>
        <Footer />
        </Suspense>
        </ErrorBoundary>
      </BrowserRouter>
    </QueryClientProvider>
  );
}

export default App;
