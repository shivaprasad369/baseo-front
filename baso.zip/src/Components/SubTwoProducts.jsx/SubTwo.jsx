import React from 'react'
import Home from '../Homepage/Home'
import Navbar from '../Homepage/Navbar'

import MultipleFilter from './Filter'
import Footer from '../Homepage/Footer'
import Categories from '../Homepage/Categories'

export default function SubTwo() {
  return (
    <>
     
      <MultipleFilter/>
  
    </>
  )
}
