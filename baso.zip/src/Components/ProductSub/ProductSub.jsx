import React from 'react'

import MultipleFilter from './Filter'
import Home from '../Homepage/Home'
import Navbar from '../Homepage/Navbar'

import Footer from '../Homepage/Footer'
import Categories from '../Homepage/Categories'
export default function ProductSub() {
  return (
    <>
  
      <MultipleFilter/>
     
    </>
  )
}
