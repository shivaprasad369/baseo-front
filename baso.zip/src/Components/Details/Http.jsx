import { useQuery, useQueryClient } from "@tanstack/react-query";
import Cookies from "js-cookie";
import axios from "axios";
import useTokenVerification from "../hooks/useTokenVerification";

export default function Http() {
  const cartNumber = Cookies.get("userId");
  const { isVerified, isLoading: isTokenLoading, user } = useTokenVerification();

  const { isLoading, error, data } = useQuery({
    queryKey: ["cart-details", cartNumber, isVerified && user?.userId],
    queryFn: async () => {
      if (!cartNumber) {
        return []; // Return an empty array if no cartNumber
      }
      try {
        const response = await axios.get(
          `http://localhost:5000/get-cart-by-number`,
          {
            params: user?.userId && isVerified
              ? { cartNumber, user: user.userId }
              : { cartNumber },
          }
        );
        return response.data.data || [];
      } catch (err) {
        // console.error("Error fetching cart details:");
        // throw err;
      }
    },
    // enabled: !!cartNumber && (isVerified ? !!user?.userId : true), // Only fetch if valid conditions are met
    // refetchOnWindowFocus: true, // Automatically refetch when window regains focus
  });

  if (isTokenLoading) {
    return { data: [], loading: true, error: null };
  }

  return { data: data || [], loading: isLoading, error };
}
