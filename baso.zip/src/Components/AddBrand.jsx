import React, { useState, useEffect } from 'react';
import axios from 'axios';

const AddBrands = () => {
    const [brandName, setBrandName] = useState('');
    const [brandImage, setBrandImage] = useState(null);
 

    const handleFileChange = (e) => {
        setBrandImage(e.target.files[0]);
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        const formData = new FormData();
        formData.append('brand', brandName);
        if (brandImage) {
            formData.append('brandImage', brandImage);
        }

        try {
            const response = await axios.post('http://localhost:5000/brands', formData, {
                headers: { 'Content-Type': 'multipart/form-data' },
            });
            alert('Brand added successfully');
            setBrandName('');
            setBrandImage(null);
            // fetchBrands(); // Refresh brand list
        } catch (error) {
            console.error('Error adding brand:', error);
            alert('Failed to add brand');
        }
    };

    return (
        <div className='w-[100%] flex items-center justify-center'>
            <div className='w-[100%] items-center justify-center max-w-[1400px] px-[7%] py-[3rem] flex flex-col gap-5'>
<div className='w-[70%] flex flex-col gap-5'>

            <h1 className='text-center text-3xl font-bold'>Manage Brands</h1>
            <form onSubmit={handleSubmit} className='w-[100%] flex flex-col gap-5'>
                <input
                    type="text"
                    placeholder="Brand Name"
                    value={brandName}
                    onChange={(e) => setBrandName(e.target.value)}
                    className='w-[100%] px-4 py-3 bg-slate-100 outline-none'
                    required
                />
                <input type="file" accept="image/*"  className='w-[100%] px-4 py-[2rem] bg-slate-100 outline-none' onChange={handleFileChange} />
                <button type="submit" className='w-fit px-6 py-3 rounded-md text-white font-bold bg-[#97f719]'>Add Brand</button>
            </form>
         
            </div>
</div>
        </div>
    );
};

export default AddBrands;
