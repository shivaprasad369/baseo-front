import React from 'react'
import Home from '../Homepage/Home'
import Navbar from '../Homepage/Navbar'
import Categories from '../Homepage/Categories'
import Footer from '../Homepage/Footer'
import MultipleFilter from './FIlter'
import ProductFilter from './FIlter'

export default function ProductContaine() {
  return (
    <>

      <ProductFilter/>
    
    </>
  )
}
